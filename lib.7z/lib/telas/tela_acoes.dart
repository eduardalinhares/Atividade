import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

class Telas_acoes extends StatefulWidget {
  const Telas_acoes({super.key});

  @override
  State<Telas_acoes> createState() => _Telas_acoesState();
}


// final args = ModalRoute.of(context)!.settings.arguments as ScreenArguments;

class _Telas_acoesState extends State<Telas_acoes> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}