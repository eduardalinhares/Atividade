import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

class Telas_bitcoins extends StatefulWidget {
  const Telas_bitcoins({super.key});

  @override
  State<Telas_bitcoins> createState() => _Telas_bitcoinsState();
}

//final args = ModalRoute.of(context)!.settings.arguments as ScreenArguments;

class _Telas_bitcoinsState extends State<Telas_bitcoins> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}